import React from 'react'
import Layout from './components/Layout';
import Home from './components/Home';
import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom";
import Category from './components/Category';
import ExploreProducts from './components/ExploreProducts';
import Register from './components/Register';
const App = () => {
  const route = createBrowserRouter([
    {
      path:"/",
      element:<Layout/>,
      children:[
        {
          index:true,
          element:<Home/>,

        },
  { path: "/category/:id",
    element: <Category />,
  },

    {
  path:"/exploreproduct",
    element:<ExploreProducts/>
    },
    {
      path:"/register",
      element:<Register/>
    }
      ]
    }
  ])
  return <RouterProvider router={route}/>
}

export default App