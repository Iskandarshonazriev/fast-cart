export default function Register() {
  return (
    <div className="min-h-screen bg-white flex items-center justify-center px-5">

      {/* CARD */}
      <div
        className="
        w-full
        max-w-[1200px]
        flex
        flex-col
        lg:flex-row
        items-center
        justify-center
        gap-20
        "
      >

      

        {/* RIGHT */}
        <div
          className="
          w-full
          max-w-[420px]
          bg-white
          p-6
          lg:p-0
          rounded-xl
          lg:bg-transparent
          
          "
        >
          <h1 className="text-[28px] lg:text-[42px] font-semibold">
            Create an account
          </h1>

          <p className="text-gray-500 mt-2">
            Enter your details below
          </p>


          {/* inputs */}

          <div className="flex flex-col gap-5 mt-10">

            <input
              type="text"
              placeholder="Name"
              className="
              h-[56px]
              border
              rounded-md
              px-4
              outline-none
              "
            />

            <input
              type="text"
              placeholder="Email or phone number"
              className="
              h-[56px]
              border
              rounded-md
              px-4
              outline-none
              "
            />

            <input
              type="password"
              placeholder="Password"
              className="
              h-[56px]
              border
              rounded-md
              px-4
              outline-none
              "
            />

          </div>



          {/* button */}

          <button
            className="
            w-full
            h-[56px]
            bg-[#DB4444]
            text-white
            rounded-md
            mt-8
            hover:opacity-90
            "
          >
            Create Account
          </button>



          {/* google */}

          <button
            className="
            w-full
            h-[56px]
            border
            rounded-md
            mt-4
            flex
            items-center
            justify-center
            gap-3
            "
          >
            <img
              src="https://cdn-icons-png.flaticon.com/512/2991/2991148.png"
              className="w-6"
            />

            Sign up with Google
          </button>



          <div className="flex justify-center gap-2 mt-8">

            <p className="text-gray-500">
              Already have account?
            </p>

            <button className="border-b">
              Log in
            </button>

          </div>

        </div>

      </div>

    </div>
  );
}