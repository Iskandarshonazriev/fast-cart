import React from 'react'
import Products from './productApi/productskidki';
import Category from './Category';
import BrowseCategory from './productApi/BrowseCategory';
import BestSelling from './productApi/BestSelling';
import MusicBanner from './productApi/MusicBanner';
import ExploreProducts from './productApi/ExploreProducts';
import NewArrival from './productApi/NewArrival';

const Todays = () => {
  return (
    <div className=" max-w-[1200px] m-auto mt-[100px]">
<div className="lg:hidden px-5 mt-10">

  {/* Today */}
  <section className="flex items-center gap-4">

    <svg
      width="16"
      height="32"
      viewBox="0 0 20 40"
      fill="none"
    >
      <rect
        width="20"
        height="40"
        rx="4"
        fill="#DB4444"
      />
    </svg>

    <b className="text-[#DB4444] text-[18px]">
      Today's
    </b>

  </section>


  {/* Flash Sales */}
  <section className="mt-6">

    <b className="text-[32px]">
      Flash Sales
    </b>

  </section>


  {/* time */}
  <section className="mt-6">

    <div className="flex justify-between text-[13px] text-gray-500">

      <p>Days</p>
      <p>Hours</p>
      <p>Minutes</p>
      <p>Seconds</p>

    </div>


    <div className="flex justify-between text-[28px] font-bold mt-2">

      <b>
        03
        <span className="text-[#E07575] ml-2">
          :
        </span>
      </b>

      <b>
        23
        <span className="text-[#E07575] ml-2">
          :
        </span>
      </b>

      <b>
        19
        <span className="text-[#E07575] ml-2">
          :
        </span>
      </b>

      <b>56</b>

    </div>

  </section>


  {/* arrows */}
  <section className="flex gap-3 mt-6">

    <button className="w-[45px] h-[45px] rounded-full bg-[#F5F5F5] flex items-center justify-center">

      ←

    </button>

    <button className="w-[45px] h-[45px] rounded-full bg-[#F5F5F5] flex items-center justify-center">

      →

    </button>

  </section>

</div>



{/* ================= ПК НЕ ТРОГАЕМ ================= */}

<div className="hidden lg:block">

<section className="flex items-center gap-[16px]">
  <svg width="20" height="40">
    <rect
      width="20"
      height="40"
      rx="4"
      fill="#DB4444"
    />
  </svg>

  <b className="text-[#DB4444]">
    Today’s
  </b>
</section>

<section className="flex items-center justify-between mt-[24px]">

<b className="text-[36px]">
Flash Sales
</b>

<section>

<section className="flex items-center gap-[55px]">

<p>Days</p>
<p>Hours</p>
<p>Minutes</p>
<p>Seconds</p>

</section>

<section className="flex items-center gap-[38px] text-[32px]">

<b>03 :</b>
<b>23 :</b>
<b>19 :</b>
<b>56</b>

</section>

</section>

<section className="flex items-center gap-[10px]">

<button>←</button>
<button>→</button>

</section>

</section>

</div>

<section>
<Products/>
<BrowseCategory/>
<hr className="mt-[100px]" />
<BestSelling/>
<hr className="mt-[100px]" />
<MusicBanner/>
<ExploreProducts/>
<NewArrival/>
</section>
    </div>
  )
}

export default Todays