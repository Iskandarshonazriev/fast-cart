import { Card } from "@/components/ui/card";
import {
  Smartphone,
  Monitor,
  Watch,
  Camera,
  Headphones,
  Gamepad2,
  ArrowLeft,
  ArrowRight,
} from "lucide-react";

const categories = [
  {
    id: 1,
    title: "Phones",
    icon: Smartphone,
  },
  {
    id: 2,
    title: "Computers",
    icon: Monitor,
  },
  {
    id: 3,
    title: "SmartWatch",
    icon: Watch,
  },
  {
    id: 4,
    title: "Camera",
    icon: Camera,
    active: true,
  },
  {
    id: 5,
    title: "HeadPhones",
    icon: Headphones,
  },
  {
    id: 6,
    title: "Gaming",
    icon: Gamepad2,
  },
];

export default function BrowseCategory() {
  return (
    <div className="max-w-[1400px] mx-auto py-14">

      {/* TOP */}
      <div className="flex items-center gap-4">

        <div className="w-8 h-16 bg-red-500 rounded-md"></div>

        <p className="text-red-500 text-2xl font-semibold">
          Categories
        </p>

      </div>

      {/* TITLE + ARROWS */}
      <div className="flex justify-between items-center mt-10">

        <h1 className="text-6xl font-bold">
          Browse By Category
        </h1>

        <div className="flex gap-5">

          <button className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition">
            <ArrowLeft size={35} />
          </button>

          <button className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition">
            <ArrowRight size={35} />
          </button>

        </div>
      </div>

      {/* CARDS */}
      <div className="grid grid-cols-6 gap-8 mt-16">

        {categories.map((item) => {
          const Icon = item.icon;

          return (
            <Card
              key={item.id}
              className={`
                h-[220px]
                flex
                flex-col
                items-center
                justify-center
                border
                cursor-pointer
                transition-all
                duration-300
                hover:bg-red-500
                hover:text-white
                hover:scale-105
                ${
                  item.active
                    ? "bg-red-500 text-white border-red-500"
                    : "bg-white"
                }
              `}
            >
              <Icon size={60} strokeWidth={1.5} />

              <p className="text-3xl mt-8">
                {item.title}
              </p>
            </Card>
          );
        })}
      </div>

    </div>
  );
}