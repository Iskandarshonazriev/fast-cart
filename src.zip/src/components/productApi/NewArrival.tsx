import { Card } from "@/components/ui/card";
import {
  Truck,
  Headphones,
  ShieldCheck,
} from "lucide-react";
import ps5 from "./productimgskidki/ps5-slim-goedkope-playstation_large 1.png"
import woman from "./productimgskidki/attractive-woman-wearing-hat-posing-black-background 1.png"
import sam from "./productimgskidki/Frame 707.png"
import duxi from "./productimgskidki/Frame 706.png"
export default function NewArrival() {
  return (
    <div className="max-w-[1400px] mx-auto py-16">

      {/* Top */}
      <div className="flex items-center gap-4">
        <div className="w-5 h-12 bg-red-500 rounded"></div>

        <p className="text-red-500 font-semibold">
          Featured
        </p>
      </div>

      <h1 className="text-5xl font-bold mt-8 mb-12">
        New Arrival
      </h1>

      {/* Grid */}
      <div className="grid grid-cols-2 gap-8">

        {/* LEFT BIG */}
        <Card className="bg-black border-none relative overflow-hidden h-[620px]">

          <img
            src={ps5}
            className="absolute inset-0 w-full h-full object-contain"
          />

          <div className="absolute bottom-10 left-8 text-white">
            <h2 className="text-4xl font-bold">
              PlayStation 5
            </h2>

            <p className="text-gray-300 mt-4 max-w-[300px]">
              Black and White version of the PS5 coming out on sale.
            </p>

            <button className="mt-5 border-b">
              Shop Now
            </button>
          </div>
        </Card>

        {/* RIGHT */}
        <div className="flex flex-col gap-8">

          {/* Women */}
          <Card className="bg-black border-none h-[300px] relative overflow-hidden">

            <img
              src={woman}
              className="absolute right-0 h-full"
            />

            <div className="absolute bottom-8 left-8 text-white">
              <h2 className="text-3xl font-bold">
                Women's Collections
              </h2>

              <p className="text-gray-300 mt-2">
                Featured woman collections that give you another vibe.
              </p>

              <button className="border-b mt-4">
                Shop Now
              </button>
            </div>

          </Card>

          {/* bottom */}
          <div className="grid grid-cols-2 gap-8">

            <Card className="bg-black h-[300px] relative overflow-hidden">

              <img
                src={sam}
                className="absolute right-0 bottom-0 w-[240px]"
              />

              <div className="absolute bottom-8 left-6 text-white">

                <h2 className="text-3xl font-bold">
                  Speakers
                </h2>

                <p className="text-gray-300">
                  Amazon wireless speakers
                </p>

                <button className="border-b mt-3">
                  Shop Now
                </button>

              </div>

            </Card>

            <Card className="bg-black h-[300px] relative overflow-hidden">

              <img
                src={duxi}
                className="absolute right-0 bottom-0 w-[230px]"
              />

              <div className="absolute bottom-8 left-6 text-white">

                <h2 className="text-3xl font-bold">
                  Perfume
                </h2>

                <p className="text-gray-300">
                  GUCCI INTENSE OUD EDP
                </p>

                <button className="border-b mt-3">
                  Shop Now
                </button>

              </div>

            </Card>

          </div>
        </div>
      </div>

      {/* Services */}
      <div className="grid grid-cols-3 gap-12 mt-28">

        <div className="text-center flex flex-col items-center">
          <div className="w-20 h-20 rounded-full bg-black text-white flex items-center justify-center">
            <Truck size={35}/>
          </div>

          <h2 className="font-bold text-2xl mt-6">
            FREE AND FAST DELIVERY
          </h2>

          <p className="text-gray-500 mt-2">
            Free delivery for all orders over $140
          </p>
        </div>

        <div className="text-center flex flex-col items-center">
          <div className="w-20 h-20 rounded-full bg-black text-white flex items-center justify-center">
            <Headphones size={35}/>
          </div>

          <h2 className="font-bold text-2xl mt-6">
            24/7 CUSTOMER SERVICE
          </h2>

          <p className="text-gray-500 mt-2">
            Friendly 24/7 customer support
          </p>
        </div>

        <div className="text-center flex flex-col items-center">
          <div className="w-20 h-20 rounded-full bg-black text-white flex items-center justify-center">
            <ShieldCheck size={35}/>
          </div>

          <h2 className="font-bold text-2xl mt-6">
            MONEY BACK GUARANTEE
          </h2>

          <p className="text-gray-500 mt-2">
            We return money within 30 days
          </p>
        </div>

      </div>
    </div>
  );
}