import { Card } from "@/components/ui/card";
import { Heart, Eye, Star } from "lucide-react";
import {Link} from "react-router-dom"
import sony from "./productimgskidki/Frame 611.png"
import klaviatura from "./productimgskidki/Frame 612.png"
import TV from "./productimgskidki/Frame 613.png"
import stol from "./productimgskidki/Frame 614.png"
const products = [
  {
    id: 1,
    title: "HAVIT HV-G92 Gamepad",
    price: "$120",
    oldPrice: "$160",
    discount: "-40%",
    rating: 5,
    reviews: 88,
    image:sony 
},
  {
    id: 2,
    title: "AK-900 Wired Keyboard",
    price: "$960",
    oldPrice: "$1160",
    discount: "-35%",
    rating: 4,
    reviews: 75,
    image:klaviatura,
    cart: true,
  },
  {
    id: 3,
    title: "IPS LCD Gaming Monitor",
    price: "$370",
    oldPrice: "$400",
    discount: "-30%",
    rating: 5,
    reviews: 99,
    image:TV
  },
  {
    id: 4,
    title: "S-Series Comfort Chair",
    price: "$375",
    oldPrice: "$400",
    discount: "-25%",
    rating: 4,
    reviews: 99,
    image:stol
  },
];

export default function Products() {
  return (
    <div className="max-w-[1400px] mx-auto py-10">

      <div className="grid md:grid-cols-4 gap-8">

        {products.map((item) => (
          <div key={item.id}>

         <Card className="group bg-[#f5f5f5] border-none p-5 relative overflow-hidden rounded-md">

  {/* Discount */}
  <div className="absolute top-4 left-4 bg-red-500 text-white px-4 py-1 rounded">
    {item.discount}
  </div>

  {/* Icons */}
  <div className="absolute right-4 top-4 flex flex-col gap-4">
    <button className="bg-white p-3 rounded-full">
      <Heart size={22} />
    </button>

    <button className="bg-white p-3 rounded-full">
      <Eye size={22} />
    </button>
  </div>

  {/* Image */}
  <div className="h-[250px] flex items-center justify-center">
    <img
      src={item.image}
      alt=""
      className="w-[230px] h-[200px] object-contain transition duration-300 group-hover:scale-105"
    />
  </div>

  {/* Add To Cart hover */}
  <button
    className="
      absolute bottom-[-60px] left-0
      w-full bg-black text-white py-4 text-xl
      transition-all duration-300
      group-hover:bottom-0
    "
  >
    Add To Cart
  </button>

</Card>

            {/* Text */}
            <div className="mt-5">

              <h2 className="font-semibold text-[28px]">
                {item.title}
              </h2>

              <div className="flex gap-4 mt-3">

                <span className="text-red-500 text-2xl font-semibold">
                  {item.price}
                </span>

                <span className="text-gray-400 text-2xl line-through">
                  {item.oldPrice}
                </span>

              </div>

              {/* Stars */}
              <div className="flex items-center gap-2 mt-3">

                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    size={20}
                    fill={i < item.rating ? "orange" : "lightgray"}
                  />
                ))}

                <span className="text-gray-500 text-xl">
                  ({item.reviews})
                </span>

              </div>

            </div>

          </div>
        ))}

      </div>

      <div className="flex justify-center mt-16">
     <Link
      to="/exploreproduct"
      className="bg-red-500 text-white px-16 py-5 rounded text-2xl inline-block"
    >
      View All Products
    </Link>
      </div>
<hr className="mt-[100px]" />
    </div>
  );
}